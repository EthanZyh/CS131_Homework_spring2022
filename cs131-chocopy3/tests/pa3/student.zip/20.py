def is_zero(items : [int], idx: int) -> bool:
    val : int = 0
    val = items[idx]
    return val == 0

mylist:  
