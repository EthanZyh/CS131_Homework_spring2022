print(1 // 0)
