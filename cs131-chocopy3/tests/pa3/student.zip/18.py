print("I'm SB hahahahaha" // 0)
